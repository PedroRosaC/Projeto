public class Main {
    public static void main(String[] args) {

        pessoa p1 = new pessoa("Pedro", 17);
        pessoa p2 = new pessoa("Jonas", 13);

        departamento d1 = new departamento("ensino", "CTISM");
        departamento d2 = new departamento("relacoesEmpresariais", "CTISM");

        p1.insereDepartamento(d1.getNome());
        p1.MostrarPessoa();

    }
}